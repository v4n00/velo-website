Velo 2.1.3 - rbit, olsu   (27/MAR/2024)



What is Velo?

Velo is a general-purpose utility mod for SpeedRunners. It allows you to customize various
aspects of the game and provides useful practice tools. You can change grapple colors, create
savestates, display a speedometer, show hitboxes and simulate blindrunning just to name a
few examples. 
Big care was taken to obey the following three principles:

-no cheating: 
    This is not a cheating mod. While it allows you to make changes to the game's physics 
    like disabling the grapple cooldown, this is limited to local games only and will
    generally be watermarked.

-no changes by default: 
    If all settings are set to their default, the game will behave just like an unmodified
    version. The only notable exceptions are the Velo leaderboard system, which is enabled by
    default, and a few local game settings to help making runs comply with the rules.

-maximum customizability:
    The mod should provide you with as much customizability for all of its features as 
    possible. If you miss a certain customization, feel free to make suggestions to further
    improve the mod.





How do I install Velo?

First you need to locate your game's installation directory. In most cases it is
"C:\Program Files (x86)\Steam\steamapps\common\SpeedRunners" (or D:, E:, ...). If you cannot
find it, then open Steam, right click "SpeedRunners" in your games list, select
"Properties..." -> "Installed Files" -> "Browse..." and it will take you there. Then,
just open the Velo .zip file, select all files and folders and drag them into the game's
installation directory. When asked, just click "Replace the files in the destination".
After that, you can launch your game from Steam like normal.





How do I uninstall Velo?

To uninstall, open Steam, right click "SpeedRunners" in your games list, select
"Properties..." -> "Installed Files" -> "Verify integrity of game files". Please note
that this will completely clear all mods that you have installed. In case you want to
keep them, please backup the "Content" folder.





How do I get started?

After launching your game, just press F1 and it will open a menu with all of Velo's settings.
To enable a specific module, just left click the little checkbox to the left of "enabled". 
To assign a hotkey, left click the text box to the left of the checkbox and press the
desired key. By right clicking you can unassign the hotkey again.





What is the difference between Velo new and Velo old?

Velo new is built upon the 25/Mar/2023 update of the game, which moved its graphics library
from XNA to FNA, while Velo old is based on the prior version that still uses XNA.
XNA is based on DirectX 9 and has long been discontinued, while with FNA you can choose
between DirectX 11, OpenGL and Vulkan. You can force a specific driver by putting
"+driver D3D11/OpenGL/Vulkan" to your game's launch options. Please note that Velo
currently does not support Vulkan! In case you experienced performance issues with the new 
update, you may want to consider using Velo old over Velo new.





How do color transitions work?

Usually, color settings are restricted to editing a single fixed color. But by clicking
the checkbox to the left, you can enable the advanced color edit. Then, just click the
color preview and you can start editing the color transition. You can add new colors by
clicking "Add Color" and remove colors by right clicking them. By left clicking, you can
edit each color. It will then just continuously cycle through the list of colors. The period
determines how long (in milliseconds) it takes for a whole cycle to complete. Some modules
allow you to bind the color transition to a different variable like speed. In that case, a
value of 0 corresponds to the first color in the list while the period determines the value
needed to reach the last color in the list.





What is the Velo leaderboard?

The Velo leaderboard is a system that allows players to easily create and share time trial
runs with each other and keep track of their rankings. There is no setup required and players
can just hop in to a solo run session and do some runs, while Velo automatically records,
validates, categorizes and submits their runs as they play, allowing for a more seamless
experience compared to speedrun.com. By pressing F2, you can access the leaderboard's menu
and see a ranking of all runs for each map and category. To view a run, just click on it in
the list and then click on "view replay". By clicking on "set ghost", you can assign the
replay to a ghost and race against it. Make sure to take a look at the rules page. Velo will
very pedantically check for these rules.





What data does the Velo leaderboard server store?

Basically, the Velo leaderboard server only stores all the information you can already
access with its menu. The only information about you it stores is your Steam name and your
runs. It does not store your IP address.





I don't want to participate in the Velo leaderboard server, how can I disable this system?

To disable the Velo leaderboard, just go to "Leaderboard" -> "general" -> "disable leaderboard"
and tick the checkbox.





It does not work, what can I do?

In most cases, this is caused by an anti-virus program. You may need to add Velo's files
to the list of exceptions or deactivate the protection entirely while installing. If you 
are unsure how it's done, just search on the internet and you will most likely find
instructions. If that still doesn't fix your issue, just ask me and we can try to find
another solution.





My game crashed, was it Velo's fault?

Most of Velo's settings should be safe and playing on default settings will not cause any
issues at all. The only really dangerous setting is "multithreaded network", which you may
want to consider disabling if you experience more frequent crashes. Loading savestates may
also cause crashes if unlucky. Don't load savestates made on different maps or it will
definitely crash. If a crash is caused by opening the settings menu, please make sure Velo
is correctly installed (drag ALL files and folders from the Velo .zip) and if that doesn't
fix the issue, consider switching your driver from D3D11 to OpenGL or back, or switching
from Velo new to Velo old or back.
For any crash, I would greatly appreciate if you could send me the "stacktrace.txt" file
it creates in the game's directory to help me make the game and mod even more crash-proof
in future.





I am unable to press F1, how do I get access to the menu?

In case you cannot press F1 for some reason, open Velo\UI.json and edit the number right
next to "Hotkey" to assign it to a different hotkey. This number represents a virtual-key 
code. To get corresponding code for a specific key, please refer to 
"https://keycode-visualizer.netlify.app/". Then save the file and restart your game.